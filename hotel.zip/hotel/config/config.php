<?php

$conn = new PDO("mysql:host=localhost;dbname=hotel", 'root', '');

include 'function.php';

session_start();