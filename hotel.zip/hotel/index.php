<?php

require_once "template/theHeader.php";

midAuth();

?>

<div class="content has-text-centered">
    <h1 class="title">Web Resepsionis Pemesanan Hotel</h1>
    <h2 class="subtitle"></h2>
</div>

<?php

require_once "template/theFooter.php"

?>