<?php

$title = 'Semua Pelanggan';

require_once "template/theHeader.php";

midAuth();

?>

<div class="level">
    <div class="level-left">
        <div class="level-item">
            <h1 class="title is-4">Customer Check In</h1>
        </div>
    </div>
   
    </div>
</div>

<hr>

<?php

if (isset($_GET['hapus'])) {
    $sql = sprintf("DELETE FROM user WHERE id_user = %s", $_GET['hapus']);
    $query = $conn->prepare($sql);

    if ($query->execute()) {
        return header('Location:customer.php');
    } else {
        $message = 'Maaf!, Tidak bisa menghapus data tersebut.';
    }
}

hasMessage();

?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Room Reservation</title>
</head>
<body>
    <h1></h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="name">NIK:</label><br>
        <input type="number" id="nik" name="nik" required><br>
        <label for="name">Nama Pemesanan:</label><br>
        <input type="text" id="name" name="name" required><br>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        <label for="phone">No. HP:</label><br>
        <input type="text" id="phone" name="phone" required><br>
        <label for="room_number">Nomor Kamar:</label><br>
        <input type="number" id="room_number" name="room_number" required><br>
        <label for="room_type">Tipe Kamar:</label><br>
        <select id="room_type" name="room_type" required>
            <option value="standard">Standard</option>
            <option value="deluxe">Deluxe</option>
            <option value="suite">Suite</option>
            <option value="standard">Elite</option>
        </select><br>
        <label for="check_in">Check-in:</label><br>
        <input type="date" id="check_in" name="check_in" required><br>
        <label for="check_out">Check-out:</label><br>
        <input type="date" id="check_out" name="check_out" required><br>
        
        <div class="level-right">
        <div class="level-item">
            <a href="customer-create.php" class="button is-light">Tambah</a>
        </div>
    </form>
</body>
</html>

    </table>
</div>

<?php

require_once "template/theFooter.php"

?>